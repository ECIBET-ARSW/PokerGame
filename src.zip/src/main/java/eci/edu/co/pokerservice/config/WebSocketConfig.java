package eci.edu.co.pokerservice.config;

public class WebSocketConfig {
}
