package eci.edu.co.pokerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokerServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
